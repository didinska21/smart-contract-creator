import { ethers, network } from "hardhat";
import readline from "readline/promises";
import { stdin as input, stdout as output } from "node:process";

const PAYMASTER = "0x459dc0dCB82c7E3c791041F9cdb5F797b6459315";

/** prompt yes / no */
async function askYesNo(question: string): Promise<boolean> {
  const rl = readline.createInterface({ input, output });
  const ans = (await rl.question(question)).trim().toLowerCase();
  rl.close();
  return ans === "y" || ans === "yes";
}

async function main() {
  const chain = network.name;
  const [deployer] = await ethers.getSigners();
  const provider = deployer.provider;

  console.log(`📡  Deploying EIP7702MultiDelegated to **${chain}**`);
  console.log(`👤  Deployer: ${await deployer.getAddress()}`);

  const factory = await ethers.getContractFactory("EIP7702MultiDelegated");

  // --- await getDeployTransaction agar txReq bukan Promise ---
  const txReq = await factory.getDeployTransaction();

  console.log("⏳ Estimating gas...");
  const gasEstimate = await provider.estimateGas(txReq);
  const gasPrice = BigInt(await provider.send("eth_gasPrice", []));
  const gasCostWei = gasEstimate * gasPrice;
  const gasCostEth = ethers.formatEther(gasCostWei);
  const ethPriceUsd = 3400;
  const costUsd = parseFloat(gasCostEth) * ethPriceUsd;

  console.log("\n📊  Perkiraan biaya deploy");
  console.log(`   • Gas digunakan : ${gasEstimate.toString()} units`);
  console.log(`   • Gas price     : ${ethers.formatUnits(gasPrice, "gwei")} gwei`);
  console.log(`   • Biaya ETH     : ${gasCostEth} ETH`);
  console.log(`   • Perkiraan USD : ~$${costUsd.toFixed(2)}`);

  if (!(await askYesNo("\n🚀  Lanjutkan deploy? (y/n): "))) {
    console.log("❌  Deploy dibatalkan.");
    return;
  }

  console.log("⏳ Mengirim transaksi deploy...");
  const contract = await factory.deploy();
  console.log("⏳ Menunggu deployment selesai...");
  await contract.waitForDeployment();

  const address = await contract.getAddress();
  console.log(`✅  Deployed at: ${address}`);
  console.log(`\n🎯 Semua token & ETH akan otomatis di-forward ke paymaster: ${PAYMASTER}`);
}

main().catch((err) => {
  console.error("❌  Deployment error:", err);
  process.exitCode = 1;
});
