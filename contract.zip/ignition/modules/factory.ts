import { buildModule } from "@nomicfoundation/hardhat-ignition/modules";
import { getCreate2Address, keccak256, toUtf8Bytes } from "ethers";
import * as hre from "hardhat";
import fs from "fs";
import path from "path";

// ==== CONFIG ====
const SALT_INPUT = "RELAYER_SALT_V1";
const SuperAdmin = "0x459dc0dCB82c7E3c791041F9cdb5F797b6459315";
const Adminer = "0x6378443f2060e9a07F36Be8f0AFDd74Ca170d824";

const FACTORY_ADDRESSES: Record<string, string> = {
  sepolia: "0xaaB9Db5F0773877957BCA1EEfEB6Abe3C3C10DDC",
  monad: "0x5E41f9BAA58592dF01Ca8F72766aDFCe5fBAAD21",
  pharos: "0x9cce65914F71e27FD54ADAD7E52302db5bAD3DeA",
  base: "0x47F2844eF61f7121B329780d298f7c8E436bd89e",
  bsc: "0x66eaB2c719682ac582F96a5e642702F245c503b4",
  gravity: "0xc428167Fb4174090969718b2030635Fb9989E465",
  polygon: "0x66eaB2c719682ac582F96a5e642702F245c503b4",
  mantle: "0x46441355F2ab6bf20e208d74216663b0C6C919C6",
  world: "0xE846e881D99cFBC172a927Cf4E76750c333DE8D7",
  linea: "0x46441355F2ab6bf20e208d74216663b0C6C919C6",
  optimism: "0x29741Eb443C3BB0fFc550CFa36Ab171ed8b1cc3F",
  arbitrumOne: "0x5b9270F293936581762d3480bE2127283D3f2C52",
};

export default buildModule("UniversalGaslessRelayerViaFactory", () => {
  // Kita abaikan contract future. Kita deploy manual via factory
  void (async () => {
    const chain = hre.network.name;
    const factoryAddress = FACTORY_ADDRESSES[chain];
    if (!factoryAddress) {
      console.error(`❌ No factory configured for network: ${chain}`);
      process.exit(1);
    }

    const artifact = await hre.artifacts.readArtifact("UniversalGaslessRelayer");
    const bytecode = artifact.bytecode;
    const salt = keccak256(toUtf8Bytes(SALT_INPUT));
    const bytecodeHash = keccak256(bytecode);
    const predictedAddress = getCreate2Address(factoryAddress, salt, bytecodeHash);

    const factory = await hre.ethers.getContractAt(
      ["function deploy(uint256 value, bytes32 salt, bytes code) external returns (address)"],
      factoryAddress
    );

    const code = await hre.ethers.provider.getCode(predictedAddress);
    if (code === "0x") {
      console.log(`⏳ Deploying to ${predictedAddress} via factory...`);
      const tx = await factory.deploy(0n, salt, bytecode, { gasLimit: 5_000_000 });
      await tx.wait();
      console.log(`✅ Deployed: ${predictedAddress}`);
    } else {
      console.log(`✅ Already deployed at ${predictedAddress}`);
    }

    // Save deployment
    const dir = path.resolve(__dirname, `../../create2-deployments/${chain}`);
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(
      path.join(dir, `${predictedAddress}.json`),
      JSON.stringify({
        address: predictedAddress,
        saltInput: SALT_INPUT,
        salt,
        bytecode,
        bytecodeHash,
        factory: factoryAddress,
        network: chain,
        timestamp: Date.now(),
      }, null, 2)
    );

    // Whitelist
    const relayer = await hre.ethers.getContractAt("UniversalGaslessRelayer", predictedAddress);
    await (await relayer.setRelayerWhitelist(SuperAdmin, true)).wait();
    await (await relayer.setRelayerWhitelist(Adminer, true)).wait();
    console.log(`✅ Whitelist done`);
  })();

  // Kembalikan kosong, biar Ignition gak mikir deploy apa-apa
  return {};
});
